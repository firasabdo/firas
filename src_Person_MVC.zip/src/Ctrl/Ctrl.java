package Ctrl;

import Entite.Ado;
import Entite.Enfant;
import Entite.Majeur;
import Model.Model;
import View.View;

public class Ctrl {

	private View vue;
	private Model model;
	
	public Ctrl(){
		vue = new View();
		model = new Model();
	}
	
	public void ctrlPersonne(){
		
		int age = vue.saisirAge();
		String type = model.traiterAge(age);
		String nom = vue.saisirNom();
		String prenom = vue.saisirPrenom();
		
		if (type == "Enfant"){
			Enfant unePersonne;
			unePersonne = new Enfant(nom,prenom,age);
			String jeu = vue.saisirJeu();
			unePersonne.setJeu(jeu);
			unePersonne.setEcole(vue.saisirEcole());
			vue.afficher(unePersonne);
		}
		else if (type == "Ado"){
			Ado unePersonne;
			unePersonne = new Ado(nom,prenom,age);
			unePersonne.setBsr(vue.saisirBsr());
			unePersonne.setEcole(vue.saisirEcole());
			vue.afficher(unePersonne);
		}
		else {
			Majeur unePersonne;
			unePersonne = new Majeur(nom,prenom,age);
			unePersonne.setVote(vue.saisirVote());
			vue.afficher(unePersonne);
		}
		
	}
}
