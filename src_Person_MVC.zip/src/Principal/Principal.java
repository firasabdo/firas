package Principal;

import Ctrl.Ctrl;

public class Principal {

	public static void main(String[] args) {
		Ctrl ctrl = new Ctrl();
		ctrl.ctrlPersonne();
	}

}
