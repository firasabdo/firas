package View;

import Dialog.Dialog;
import Entite.Ado;
import Entite.Enfant;
import Entite.Majeur;


public class View {

	private Dialog dialog;
	
	public View(){
		dialog = new Dialog();
	}
	
	public int saisirAge(){
		int age = dialog.saisirEntier("Veuillez saisir votre age : ", "Age");	
		return age;
	}
	
	public String saisirNom(){
		String nom = dialog.saisirChaine("Veuillez saisir votre nom : ", "Nom");
		
		return nom;
	}
	
	public String saisirPrenom(){
		String prenom = dialog.saisirChaine("Veuillez saisir votre pr�nom : ", "Pr�nom");
		
		return prenom;
	}

	public String saisirJeu() {
		String jeu = dialog.saisirChaine("Quel est votre jeu pr�f�r� ? : ", "Jeu");
		return jeu;
	}
	
	public String saisirEcole() {
		String ecole = dialog.saisirChaine("Quel est le nom de votre �cole ? : ", "Ecole");
		return ecole;
	}
	
	public boolean saisirVote() {
		boolean b = dialog.saisirOuiNon("Votez-vous ? : ", "Vote");
		return b;
	}
	
	public boolean saisirBsr() {
		boolean b = dialog.saisirOuiNon("Avez-vous le BSR ? : ", "BSR");
		return b;
	}
	
	public void afficher(Enfant e){
		dialog.afficherChaine(e.afficher(), "R�sultat");
	}
	
	public void afficher(Ado a){
		dialog.afficherChaine(a.afficher(), "R�sultat");
	}
	
	public void afficher(Majeur m){
		dialog.afficherChaine(m.afficher(), "R�sultat");
	}
}

