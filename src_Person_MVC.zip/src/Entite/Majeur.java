package Entite;

public class Majeur extends Personne{

	private boolean vote;
	
	public Majeur(){
		super();
	}
	
	public Majeur(String nom, String prenom, int age){
		super(nom,prenom,age);
	}
	
	public boolean isVote() {
		return vote;
	}

	public void setVote(boolean vote) {
		this.vote = vote;
	}
	
	private String conduire(){
		return "Je conduis\n";
	}
	
	/**
	 * Redefinition de afficher()
	 */
	@Override
	public String afficher(){
		String msg = super.afficher();
		msg += this.conduire();
		if(this.isVote())
			msg += "Je vote\n";
		else
			msg += "Je ne vote pas\n";
		return msg;
	}


}
