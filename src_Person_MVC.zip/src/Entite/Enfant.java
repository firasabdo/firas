package Entite;

public class Enfant extends Mineur{

	private String jeu;
	
	public Enfant(){
		super();
	}
	
	public Enfant(String nom, String prenom, int age){
		super(nom,prenom,age);
	}

	public String getJeu() {
		return jeu;
	}

	public void setJeu(String jeu) {
		this.jeu = jeu;
	}
	
	public String allerAEcole(){
		String msg = "";
		msg = "Je vais � l'�cole\n";
		return msg;
	}
	
	/**
	 * Redefinition de afficher()
	 */
	@Override
	public String afficher(){
		String msg = super.afficher();
		msg += this.allerAEcole();
		msg += "Mon jeu pr�f�r� : " + this.getJeu() + "\n";
		return msg;
	}
}
