package Entite;

public class Ado extends Mineur {

	private boolean bsr;
	
	public Ado(){
		super();
	}

	public Ado(String nom, String prenom, int age){
		super(nom,prenom,age);
	}
	
	public boolean isBsr() {
		return bsr;
	}

	public void setBsr(boolean bsr) {
		this.bsr = bsr;
	}
	
	public String allerAuCollege(){
		String msg = "";
		msg = "Je vais au coll�ge\n";
		return msg;
	}
	
	/**
	 * Redefinition de afficher()
	 */
	@Override
	public String afficher(){
		String msg = super.afficher();
		if(this.isBsr())
			msg += "J'ai le BSR\n";
		else
			msg += "Je n'ai pas le BSR\n";
		return msg;
	}
}
