package Entite;

public class Mineur extends Personne {

	private String ecole;
	
	public Mineur(){
		super();
	}

	public Mineur(String nom, String prenom, int age){
		super(nom,prenom,age);
	}
	public String getEcole() {
		return ecole;
	}

	public void setEcole(String ecole) {
		this.ecole = ecole;
	}
	

	/**
	 * Redefinition de afficher()
	 */
	@Override
	public String afficher(){
		String msg = super.afficher();
		msg += "Mon �cole : " + this.getEcole() + "\n";
		return msg;
	}
}
