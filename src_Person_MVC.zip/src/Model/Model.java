package Model;

public class Model {

	public Model(){
		
	}
	
	public String traiterAge(int age){
		String r = "";
		if(age >= 18)
			r = "Majeur";
		else if(age < 12)
			r = "Enfant";
		else
			r = "Ado";
		return r;
	}
}
