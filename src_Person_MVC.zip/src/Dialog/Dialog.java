package Dialog;

import javax.swing.JOptionPane;

public class Dialog {

	public Dialog(){
		
	}

	
	public int saisirEntier(String msg, String titre) {
		boolean ok = false;
		String[] messages = { "Vous devez saisir un entier !" };
		int entier = 0;
		// TODO Controler le bouton Annuler et la croix pour fermer la dialogbox
		do{
            try{
            	entier = Integer.parseInt(JOptionPane.showInputDialog(null,msg,titre,JOptionPane.QUESTION_MESSAGE));
            	ok = true;
            }
            catch (Exception e){
                JOptionPane.showMessageDialog(null, messages[0], "Erreur", JOptionPane.WARNING_MESSAGE);
            }
            

        }while(ok == false);
		return entier;
	}
	
	public String saisirChaine(String msg, String titre){
		String s = "";
		boolean ok = false;
		String[] messages = { "Vous devez saisir une chaine de caract�res !" };

		// TODO Controler le bouton Annuler et la croix pour fermer la dialogbox
		do{
            try{
            	s = JOptionPane.showInputDialog(null,msg,titre,JOptionPane.QUESTION_MESSAGE);
            	ok = true;
            }
            catch (Exception e){
                JOptionPane.showMessageDialog(null, messages[0], "Erreur", JOptionPane.WARNING_MESSAGE);
            }
            

        }while(ok == false);
		return s;
	}
	
	public boolean saisirOuiNon(String msg, String titre){
		int i = 0;
		boolean ok = false;
		String[] messages = { "Vous devez choisir OUI ou NON !" };

		// TODO Controler le bouton Annuler et la croix pour fermer la dialogbox
		do{
            try{
            	i = JOptionPane.showConfirmDialog(null,msg,titre,JOptionPane.YES_NO_OPTION);
            	ok = true;
            }
            catch (Exception e){
                JOptionPane.showMessageDialog(null, messages[0], "Erreur", JOptionPane.WARNING_MESSAGE);
            }
            

        }while(ok == false);
		return (i == 0) ? true : false;
	}
	
	public void afficherChaine(String msg, String titre){
		JOptionPane.showMessageDialog(null, msg, titre, JOptionPane.INFORMATION_MESSAGE);
	}
}
